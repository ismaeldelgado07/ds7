<html>
    <head>
        <title>
            Parcial 2
        </title>
    </head>

    <body>
        <center>
            <h1>
            <form name ="enviarNumero" method="POST" action="calcular.php">
                <h1>
                    Cálculo de un factorial
                </h1><br>
                <h2>Ingresa un número</h2> 
                <input name="numero" type="text" value="">
                <input name="enviarNumero" type="submit" value="Enviar">
            </form>
            </h1>

        </center>
    </body>
</html>